//go:generate go run mage.go -v Generate

package main
